﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.DataEntity
{
    public class SearchForRestautrant
    {
        public LocationDetails location { get; set; }
        public AddtitionalFeatureForSearch search { get; set; }
    }
}
