﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer
{
    public class ConnectionStrings
    {
        public string DatabaseConnectionString { get; set; }
        public string RestaurantApiUrl { get; set; }
    }
}
