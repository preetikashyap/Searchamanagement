﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer
{
    public class ConnectionString
    {
        public string DatabaseConnectionString { get; set; }
    }
}
