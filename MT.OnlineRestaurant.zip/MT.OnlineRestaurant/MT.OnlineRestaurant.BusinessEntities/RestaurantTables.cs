﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.BusinessEntities
{
    public class RestaurantTables
    {
        public string restaurant_Name { get; set; }
        public int table_Capacity { get; set; }
        public int total_Count { get; set; }
    }
}
